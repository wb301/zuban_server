#!/bin/bash
#同步php
/usr/bin/rsync -av \
    --exclude '.git' \
    --exclude '.DS_Store' \
    --exclude 'Runtime' \
	../zhaopin/frontend root@192.168.199.199:/data/htdocs/zhaopin