<?php
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=onefit',
            'username' => 'root',
            'password' => 'fd09a69307a053',
            'charset' => 'utf8',
        ],
    ],
];
