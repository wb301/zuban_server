<?php
return [
    'vendorPath' => dirname(dirname(__DIR__)) . '/vendor',
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=onefit',
            'username' => 'root',
            'password' => 'fd09a69307a053',
            'charset' => 'utf8',
        ],
        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],
        'helper'=> [
            'class' => 'common\components\Helper',
            'property'  => '123',
        ],
        'actiontime'=>[
            'class' => 'common\components\ActionTimeFilter',
        ]
    ],
    
    'modules'	=> [
    	'app1'	=> [
    		'class'	=> 'common\modules\app1\App1Module',
    	],
    	'app2'	=> [
    		'class'	=> 'common\modules\app2\App2Module',
    	],
    ],
];
