<?php

namespace common\components;

class Helper
{
    public function checkedMobile($mobile)
    {
        return $mobile;
    }
}