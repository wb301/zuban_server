<?php

namespace common\components;

use Yii;
use yii\base\ActionFilter;

class ActionTimeFilter extends ActionFilter
{
    private $_startTime;

    function beforeAction($action)
    {
        $this->_startTime = microtime(true);
        return parent::beforeAction($action);
    }

    function afterAction($action, $result)
    {
        $spend_time = microtime(true) - $this->_startTime;

        Yii::trace("Action '{$action->uniqueId}' spent {$spend_time} seconds.");
        return parent::afterAction($action, $result);
    }
}