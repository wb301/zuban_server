<?php

namespace common\modules\app2\controllers;

use yii\web\Controller;

class C3Controller extends Controller
{
	// http://yii2.stamhe.com/index.php?r=app2/c3/hello
    function actionHello()
    {
        echo "Hello C3 controller in App2";
    }
    
    // http://yii2.stamhe.com/index.php?r=app2/c3/view3
    function actionView3()
    {
    	$username = "View3 in C3 Controller of App2";
    	return $this->renderPartial('c3view3', ['username' => $username]);
    }
}