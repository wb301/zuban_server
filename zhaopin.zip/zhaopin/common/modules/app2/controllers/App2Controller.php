<?php

namespace common\modules\app2\controllers;

use yii\web\Controller;

class App2Controller extends Controller
{
    function actionHello()
    {
        echo "Hello App2";
    }
}