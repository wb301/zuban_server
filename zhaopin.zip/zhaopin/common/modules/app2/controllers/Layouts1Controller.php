<?php

namespace common\modules\app2\controllers;

use yii\web\Controller;

ini_set("display_errors","on");
error_reporting(E_ALL);

class Layouts1Controller extends Controller
{
	public $layout = 'layouts1';
	
	function actionView1()
	{
		$username = "HeQuan";
		$this->render('l1v1', ['username' => $username]);
	}
	
	function actionView2()
	{
		$username = "StamHe";
		$this->render('l1v2', ['username' => $username]);
	}
}