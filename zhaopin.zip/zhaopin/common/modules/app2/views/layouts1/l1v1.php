<?php
use yii\helpers\Html;
?>

<?php echo Html::encode($username); ?>
