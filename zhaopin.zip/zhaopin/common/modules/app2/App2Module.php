<?php

namespace common\modules\app2;
use yii\base\Module;

class App2Module extends Module
{
    public function init()
    {
        parent::init();
    }
}