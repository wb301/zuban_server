<?php

namespace common\modules\app1;
use yii\base\Module;

class App1Module extends Module
{
    public function init()
    {
        parent::init();
    }
}