<?php

namespace common\modules\app1\controllers;

use yii\web\Controller;

class App1Controller extends Controller
{
    public $defaultAction = "hello";
    
    function actionHello()
    {
        echo "Hello App1 of App1/App1Controller";
    }
}