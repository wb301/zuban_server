<?php

namespace frontend\models;

use Yii;

class ResumeSchedule extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'user_resume_schedule';
    }

    /**
     * @return \yii\db\Connection the database connection used by this AR class.
     */
    public static function getDb()
    {
        return Yii::$app->get('db');
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['resume_id','salary'], 'integer'],
            [['updated_time', 'created_time'], 'safe'],
            [['company'], 'string', 'max' => 80],
            [['job'], 'string', 'max' => 80],
            [['job_images','body_images','job_exp'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'company' => 'Company',
            'resume_id' => 'Resume Id',
            'job' => 'Job',
            'job_exp' => 'Job Exp',
            'salary' => 'Salary',
            'job_images' => 'Job Images',
            'body_images' => 'Body Images',
            'remark' => 'Remark',
            'updated_time' => 'Updated Time',
            'created_time' => 'Created Time',
        ];
    }
}
