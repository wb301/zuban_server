<?php

namespace frontend\models;

use Yii;

class Resume extends \yii\db\ActiveRecord
{
    public function getSex_desc()
    {

        return ($this->sex == 1)?"男":(($this->sex == 0)?"未填":"女");
    }


    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'user_resume';
    }

    /**
     * @return \yii\db\Connection the database connection used by this AR class.
     */
    public static function getDb()
    {
        return Yii::$app->get('db');
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['uid', 'job_status','status','sex','province_id','city_id','scope','audit_status'], 'integer'],
            [['birthday', 'updated_time', 'created_time','study_time'], 'safe'],
            [['title','name','province','city'], 'string', 'max' => 50],
            [['mobile'], 'string', 'max' => 15],
            [['study_content'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'uid' => 'Uid',
            'title' => 'Title',
            'name' => 'Name',
            'sex' => 'Sex',
            'mobile' => 'Mobile',
            'birthday' => 'Birthday',
            'province' => 'Province',
            'city' => 'City',
            'province_id' => 'Province ID',
            'city_id' => 'City ID',
            'study_time' => 'Study Time',
            'study_content' => 'Study Content',
            'scope' => 'Scope',
            'audit_status' => 'Audit Status',
            'job_status' => 'Job Status',
            'status' => 'Status',
            'updated_time' => 'Updated Time',
            'created_time' => 'Created Time',
        ];
    }
}
