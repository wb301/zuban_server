<?php

namespace frontend\models;

use Yii;

class StaffUser extends \yii\db\ActiveRecord
{
    public function setPassword( $password ) {

        $this->login_pwd = $this->getSaltPassword($password);
    }


    public function setSalt( $length = 16 ){
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
        $salt = '';
        for ( $i = 0; $i < $length; $i++ ){
            $salt .= $chars[ mt_rand(0, strlen($chars) - 1) ];
        }
        $this->salt = $salt;
    }

    public function getSaltPassword($password) {
        return md5($password.md5($this->salt));
    }


    public function verifyPassword($password) {
        return $this->login_pwd === $this->getSaltPassword($password);
    }


    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'staff_user';
    }

    /**
     * @return \yii\db\Connection the database connection used by this AR class.
     */
    public static function getDb()
    {
        return Yii::$app->get('db');
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['uid', 'login_status','status'], 'integer'],
            [['last_active_time', 'updated_time', 'created_time'], 'safe'],
            [['nickname'], 'string', 'max' => 50],
            [['mobile'], 'string', 'max' => 15],
            [['login_pwd', 'salt'], 'string', 'max' => 32]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'uid' => 'Uid',
            'nickname' => 'Nickname',
            'mobile' => 'Mobile',
            'login_status' => 'Login Status',
            'login_name' => 'Login Name',
            'login_pwd' => 'Login Pwd',
            'salt' => 'Salt',
            'status' => 'Status',
            'last_active_time' => 'Last Active Time',
            'updated_time' => 'Updated Time',
            'created_time' => 'Created Time',
        ];
    }
}
