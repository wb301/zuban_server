<?php

namespace frontend\models;

use Yii;

class StaffJob extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'staff_job';
    }

    /**
     * @return \yii\db\Connection the database connection used by this AR class.
     */
    public static function getDb()
    {
        return Yii::$app->get('db');
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['uid','status','province_id','city_id','salary','audit_status','num'], 'integer'],
            [['updated_time', 'created_time'], 'safe'],
            [['job','name','province','city'], 'string', 'max' => 50],
            [['mobile'], 'string', 'max' => 15],
            [['info','address','images','welfare','require'], 'string', 'max' => 255]
        ];
    }


    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'uid' => 'UID',
            'name' => 'Name',
            'mobile' => 'Mobile',
            'info' => 'Info',
            'province_id' => 'Province_Id',
            'city_id' => 'City Id',
            'province' => 'Province',
            'city' => 'City',
            'address' => 'Address',
            'images' => 'Images',
            'job' => 'Job',
            'salary' => 'Salary',
            'num' => 'Num',
            'welfare' => 'Welfare',
            'require' => 'Require',
            'audit_status' => 'Audit Status',
            'status' => 'Status',
            'updated_time' => 'Updated Time',
            'created_time' => 'Created Time',
        ];
    }
}
