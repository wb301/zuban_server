<?php

namespace frontend\models;

use common\components\HttpClient;
use Yii;

/**
 * This is the model class for table "sms_captcha".
 *
 * @property integer $id
 * @property string $mobile
 * @property string $captcha
 * @property string $expires_at
 * @property string $ip
 * @property integer $status
 * @property string $created_time
 */
class SmsCaptcha extends \yii\db\ActiveRecord
{
    public static function send($mobile, $content ) {
        $sign = "三体云动";
        if(is_array($mobile))
            $mobile = implode(',',$mobile);

       $data = [
            'un' => 'N3182155',
            'pw' => '80bAC9iR5o7040',
            'phone' => is_array($mobile) ? implode(',',$mobile) : $mobile,
            'msg' => str_replace('+',urlencode('+'),strval("【{$sign}】".$content)),
            'rd' => '1',
        ];
        $ret = HttpClient::post("https://sms.253.com/msg/send",$data);

        return $ret;
    }

    public static function checkCaptcha($mobile, $captcha, $type=1)
    {
        $mobile = trim($mobile);
        $captcha = str_replace(' ', '', $captcha);

        $captcha = self::findOne(['mobile' => $mobile, 'captcha' => $captcha]);
        if ($captcha && strtotime($captcha->expires_at) >= time()) {
            $captcha->expires_at = date("Y-m-d H:i:s", time() - 1);
            $captcha->save();
            return true;
        }

        return false;
    }


    public function geneCaptcha($mobile,$type=1,$sign='' ,$channel='') {
        $ip = HttpClient::getIP();
        if(!$this->allow_send_captcha($mobile,$ip))
        {
            return false;
        }
        $this->mobile = $mobile;
        $this->created_time = date("Y-m-d H:i:s",time());
        $this->captcha = (string) rand(10000,99999);
        $this->expires_at = date("Y-m-d H:i:s",time() + 60*10);
        $this->ip = $ip;
        $this->type = $type;
        $this->status = 0;

        return $this->save(0);
    }

    public  function geneCustomCaptcha($mobile,$type=1,$content,$sign = '',$channel = ''){
        $ip = HttpClient::getIP();
        if(empty($content)){
            return false;
        }

        //客户的短信暂时不检查ip限制吧
        if(!$this->allow_send_captcha($mobile,0))
        {
            return false;
        }
        $this->mobile = $mobile;
        $this->created_time = date("Y-m-d H:i:s",time());
        $this->captcha = (string) rand(10000,99999);
        $this->expires_at = date("Y-m-d H:i:s",time() + 60*10);
        $this->ip = $ip;
        $this->type = $type;
        $this->status = 0;
        $content = str_replace("xxxx",$this->captcha,$content);

        return $this->save(0);
    }

    public static function getLastCaptcha($mobile,$type=1) {
        return SmsCaptcha::find()
            ->where(['mobile' => $mobile, 'type' => $type])
            ->orderBy('created_time desc')
            ->limit(1)
            ->one();
    }

    public function allow_send_captcha($mobile,$ip='')
    {
        $time_limits = [
            1 => 2,
            5 => 3,
            60 => 5,
            1440 => 8
        ];//minute => count

		//当天限制
        $captcha_records = $this->find()
			->where(['mobile' => $mobile])
			->andWhere([ '>=','created_time',date("Y-m-d 00:00:00") ])
			->orderBy('id desc')
			->limit(8)
			->all();

        foreach($time_limits as $minute => $count)
        {
            if(isset($captcha_records[$count-1]) && strtotime($captcha_records[$count-1]['created_time']) > time() - $minute*60)
            {
                return false;
            }
        }
        if($ip)
        {

            $captcha_records = $this->find()
                ->where(['ip' => $ip])
                ->andWhere([ '>=','created_time',date("Y-m-d 00:00:00") ])
                ->orderBy('id desc')
                ->limit(8)
                ->all();

            foreach($time_limits as $minute => $count)
            {

                if(isset($captcha_records[$count-1]) && strtotime($captcha_records[$count-1]['created_time']) > time() - $minute*60)
                {
                    return false;
                }
            }
        }
        return true;
    }


    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'sms_captcha';
    }

    /**
     * @return \yii\db\Connection the database connection used by this AR class.
     */
    public static function getDb()
    {
        return Yii::$app->get('db');
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['expires_at', 'created_time'], 'safe'],
            [['status'], 'required'],
            [['status','type'], 'integer'],
            [['mobile'], 'string', 'max' => 20],
            [['captcha'], 'string', 'max' => 10]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'mobile' => 'Mobile',
            'captcha' => 'Captcha',
            'expires_at' => 'Expires At',
            'type' => 'Type',
            'status' => 'Status',
            'created_time' => 'Created Time',
        ];
    }
}
