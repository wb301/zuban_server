<?php

namespace frontend\assets;

use yii\web\AssetBundle;

/**
 * Main frontend web asset bundle.
 */
class AdminAsset extends AssetBundle
{
    public $basePath = '@webroot';
    public $baseUrl = '@web';
    public $css = [
        'css/libs/normalize.css',
        'css/libs/foundation-5.5.3.min.css',
        'css/component/font-awesome.min.css',
        'css/admin/app.css'
    ];
    public $js = [
        'js/libs/jquery-1.12.4.min.js',
        'js/component/tether.min.js',
        'js/component/tooltip.min.js',
        'js/libs/foundation.min.js',
        'js/admin/common.js'
    ];
}
