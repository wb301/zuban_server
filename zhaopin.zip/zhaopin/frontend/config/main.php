<?php
$params = array_merge(
    require(__DIR__ . '/../../common/config/params.php'),
    require(__DIR__ . '/../../common/config/params-local.php'),
    require(__DIR__ . '/params.php'),
    require(__DIR__ . '/params-local.php')
);

return [
    'id' => 'app-frontend',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'controllerNamespace' => 'frontend\controllers',
    'components' => [
        'request' => [
            'csrfParam' => '_csrf-frontend',
        ],
        'user' => [
            'identityClass' => 'common\models\User',
            'enableAutoLogin' => true,
            'identityCookie' => ['name' => '_identity-frontend', 'httpOnly' => true],
        ],
        'session' => [
            // this is the name of the session cookie used for login on the frontend
            'name' => 'advanced-frontend',
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning', 'info', 'trace'],
                ],
            ],
        ],
        'errorHandler' => [
            'errorAction' => 'site/error',
        ],
        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'enableStrictParsing' => false,
            'rules' => [
                '<controller:\w+>/<action:\w+>' => '<controller>/<action>',
            ],
        ],
    ],
    'params' => $params,

    /*
    // 处理所有用户请求的控制器方法，全网维护时启用
    'catchAll'  =>[
        'site/newindex',
        'param1'    => '网站维护，马上回来...',
    ],
    */
    'controllerMap' => [
        'site100' => 'frontend\controllers\SiteController',
    ],

    // 时区
    'timeZone'  => 'Asia/Shanghai',
    // 应用使用的字符集，默认值为"UTF-8"
    'charset'   => 'UTF-8',
    // 默认控制器
    'defaultRoute'  => 'user',
    'aliases'   => [
        '@test1path'    => '@app/test1',
        '@test2path'    => '@app/test2',
    ],

    // 指定应用的版本
    'version'   => '2.0.x',
];
