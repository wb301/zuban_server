<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use frontend\assets\AdminAsset;
use common\widgets\Alert;

AdminAsset::register($this);
?>
<?php $this->beginPage() ?>
    <!DOCTYPE html>
    <html class="no-js">
    <head>
        <meta charset="utf-8">
        <link rel="icon" href="/img/favicon.ico" type="image/x-icon" />
        <title>Onefit招聘</title>
        <?php $this->head() ?>
        <?php $this->beginBody() ?>
    </head>
    <body>
    <div class="wrap">
      <div class="container">
        <!-- 顶部导航 -->
        <nav class="topNav">
          <div class="right">
            <div class="user_area">
              <div class="sys_pop user_avatar">
                <img src="https://pic1-s.styd.cn/d413a72e2f656ae484b1e3be373656b5?imageView2/1/w/100/h/100/interlace/1" alt="">
              </div>
              <div class="mod_popup">
                <ul class="user_list">
                  <li>
                      <a href="javascript:void(0);">退出</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </nav>

        <div class="containerInner">
          <div class="template">
          <?php echo $content ?>
          </div>
        </div>

        <div class="footNav">
            Copyright © 2017 <a href="http://www.styd.cn/" target="_blank">三体云动</a> | <a href="http://www.styd.cn/web/user/feedback" target="_blank">问题反馈</a> | <a href="http://www.styd.cn/default/faq" target="_blank"> 帮助中心</a> | <a href="http://bbs.styd.cn/forum.php" target="_blank"> 官方论坛</a> |&emsp;联系电话：400-962-8988
        </div>
      </div>
    </div>

    <?php $this->endBody() ?>
    </body>
    </html>
<?php $this->endPage() ?>
