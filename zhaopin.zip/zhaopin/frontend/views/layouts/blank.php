<?php
use yii\helpers\Html;
use yii\widgets\Breadcrumbs;
use frontend\assets\BlankAsset;

BlankAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="icon" href="/img/favicon.ico" type="image/x-icon" />
    <title>Onefit招聘</title>
    <?php $this->head() ?>
    <?php $this->beginBody() ?>
</head>
<body>
    <div class="wrap">
        <?php echo $content ?>
    </div>
    <?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
