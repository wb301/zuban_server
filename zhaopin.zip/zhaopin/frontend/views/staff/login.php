<?php
use frontend\components\UrlService;
use frontend\components\StaticService;

StaticService::includeAppCssStatic("/css/staff/login.css",\frontend\assets\AppAsset::className());
StaticService::includeAppJsStatic("/js/staff/login.js",\frontend\assets\AppAsset::className());
?>
<div id="wrap">
    <div class="title">
        <h2>登录</h2>
        <a href="<?=UrlService::buildZpUrl('register');?>" class="register">注册</a>
    </div>
    <div class="login_form">
        <div class="input_wrap tel">
            <input type="tel" name="mobile" class="input_w1" placeholder="请输入手机号">
        </div>
        <div class="input_wrap pwd">
            <input type="password" name="pwd" class="input_w1" placeholder="请输入登录密码">
        </div>
    </div>
    <div class="forget_psw">
        <a href="<?=UrlService::buildZpUrl('forget');?>">忘记密码？</a>
    </div>
    <a href="javascript:void(0);" class="login_btn">登录</a>
</div>
