<?php
use frontend\components\UrlService;
use frontend\components\StaticService;

StaticService::includeAppCssStatic("/css/staff/edit.css",\frontend\assets\AppAsset::className());
StaticService::includeAppJsStatic("/js/staff/edit.js",\frontend\assets\AppAsset::className());
StaticService::includeAppJsStatic("/js/component/qiniu.min.js",\frontend\assets\AppAsset::className());
StaticService::includeAppJsStatic("/js/component/plupload.full.min.js",\frontend\assets\AppAsset::className());
?>
<div id="wrap">
    <input type="hidden" id="images_id" value='<?= json_encode($resume['images']) ?>' >
    <?php if($resume['audit_status'] == 1):?>
        <p class="resume_status approved">招聘信息审核通过</p>
    <?php elseif($resume['audit_status'] == 2):?>
        <p class="resume_status reject">招聘信息未通过审核，请编辑后重新提交</p>
    <?php elseif($resume['audit_status'] == 0):?>
        <p class="resume_status await">招聘信息已提交，待审核</p>
    <?php endif;?>
    <h3 class="resume_title">公司信息</h3>
    <div class="resume_form">
        <ul class="form_list">
            <li>
                <label class="title required">公司名称:</label>
                <div class="input_box">
                    <input type="text" class="type_1" name="company_name" placeholder="请填写" value="<?= $resume['name'] ?>">
                </div>
            </li>
            <li>
                <label class="title required">公司电话:</label>
                <div class="input_box">
                    <input type="tel" class="type_1" name="company_mobile" placeholder="请填写" value="<?= $resume['mobile'] ?>">
                </div>
            </li>
        </ul>
    </div>
    <h3 class="resume_title">公司简介(必填)</h3>
    <div class="resume_form">
        <div class="text_exp">
            <textarea name="company_info" placeholder="请填写公司简介（200-300字）" maxlength="300"><?= $resume['info'] ?></textarea>
        </div>
    </div>
    <h3 class="resume_title">公司照片(请上传6张公司实景照)(必填)</h3>
    <div class="resume_form pdt">
        <ul id="images" class="upload_list company_photo">
        <?php if (count($resume['images']) > 0): ?>
            <?php foreach ($resume['images'] as $key => $value): ?>
                 <li><img src='<?= "https://pic3-s.styd.cn/".$value."?imageView2/1/w/120/h/120/interlace/1" ?>' alt=""></li>
            <?php endforeach ?>
        <?php endif ?>
        </ul>
        <form method="post" action="http://upload.qiniu.com/"  enctype="multipart/form-data">
            <div class="upload_box" id="images">
                    <div id="pickfiles_container" class="type_upload">
                      <input type="button" id="pickfiles" style="width: 100%; height: 100%" />
                    </div>
            </div>
        </form>
    </div>
    <h3 class="resume_title">招聘详情</h3>
    <div class="resume_form">
        <ul class="form_list">
            <li>
                <label class="title required">招聘职位:</label>
                <div class="input_box">
                    <input name="job_position" type="text" class="type_1" placeholder="请填写" value="<?= $resume['job'] ?>">
                </div>
            </li>
            <li>
                <label class="title required">职位薪酬:</label>
                <div class="input_box arrow_right">
                    <select class="type_1" name="job_salary">
                        <?php foreach ($resume['salary_list'] as $key => $value): ?>
                            <option value="<?= $value['id'] ?>" <?php if($value['selected'] > 0):?> selected="selected" <?php endif;?> ><?= $value['name'] ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
            </li>
            <li>
                <input type="hidden" id="city_id_id_before" value="<?= $resume['city_id'] ?>">
                <label class="title required">工作地点:</label>
                <div class="input_box">
                    <select class="type_2" name="province_id" id="province_id" >
                        <option value="0">省份</option>
                        <?php foreach ($province_mapping as $_province_id => $_province_name): ?>
                            <option value="<?= $_province_id ?>"
                                    <?php if ($_province_id == $resume['province_id']): ?> selected="selected"<?php endif; ?>><?= $_province_name ?> </option>
                        <?php endforeach; ?>
                    </select>
                    <select class="type_2" name="city_id" id="city_id" >
                        <option value="<?= $resume['city_id'] ?>"><?= $resume['city'] ?></option>
                    </select>
                </div>
            </li>
            <li>
                <div class="input_box">
                    <input name="job_address" type="text" class="type_1" placeholder="具体地址" value="<?= $resume['address'] ?>">
                </div>
            </li>
            <li>
                <label class="title required">招聘人数:</label>
                <div class="input_box">
                    <input  onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')"  name="job_count" type="text" class="type_1" placeholder="请填写" value="<?= $resume['num_str'] ?>">
                </div>
            </li>
            <li>
                <label class="title">福利待遇:</label>
                <div class="tag_box">
                    <ul class="tag_list">
                        <?php foreach ($resume['welfare_list'] as $key => $value): ?>
                            <li value="<?= $value['id'] ?>" <?php if($value['selected'] > 0):?> class="selected" <?php endif;?> ><?= $value['name'] ?></li>
                        <?php endforeach ?>
                    </ul>
                </div>
            </li>
        </ul>
    </div>
    <h3 class="resume_title">岗位要求(必填)</h3>
    <div class="resume_form">
        <div class="text_exp">
            <textarea name="job_info" placeholder="请填写岗位要求" maxlength="200"><?= $resume['require'] ?></textarea>
        </div>
    </div>
    <a href="javascript:void(0);" class="save">保存提交</a>
</div>
