<?php
use frontend\components\UrlService;
use frontend\components\StaticService;
StaticService::includeAppCssStatic("/css/admin/login.css",frontend\assets\BlankAsset::className());
StaticService::includeAppJsStatic("/js/admin/login.js",frontend\assets\BlankAsset::className());
?>
<div class="user_box">
  <h2>
    <img src="https://static-s.styd.cn/201704271041/timg.png?imageView2/0/w/180/interlace/1" alt="">
  </h2>
  <form action="" method="post" id="login">
      <ul class="user_input pd-0">
        <li>
          <label class="label_box user_name">用户名</label>
          <input type="text" class="input_box input_name" name="login_name" placeholder="请输入用户名" >
        </li>
        <li>
          <label class="label_box user_password">密码</label>
          <input type="password" class="input_box input_password" name="login_pwd" placeholder="请输入密码">
        </li>
      </ul>
      <div class="user_button">
        <a href="javascript:void(0);" class="btn_submit dologin">登录</a>
      </div>
  </form>
</div>
