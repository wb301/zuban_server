<?php
use frontend\components\UrlService;
use frontend\components\StaticService;
StaticService::includeAppCssStatic("/css/component/daterangepicker-f5.css", \frontend\assets\AdminAsset::className());
StaticService::includeAppCssStatic("/css/component/lightbox.min.css",\frontend\assets\AdminAsset::className());
StaticService::includeAppJsStatic("/js/component/lightbox.min.js",\frontend\assets\AdminAsset::className());
StaticService::includeAppJsStatic("/js/libs/moment.min.js", \frontend\assets\AdminAsset::className());
StaticService::includeAppJsStatic("/js/component/daterangepicker.js", \frontend\assets\AdminAsset::className());
StaticService::includeAppJsStatic("/js/admin/resume.js",\frontend\assets\AdminAsset::className());
?>
<ul class="pageTab">
  <li><a href="javascript:void(0);" class="current">简历列表</a></li>
</ul>
<div class="mainContent">
  <div class="modules">
    <form method="get" id="search_condition">
        <div class="row filter_fix">
            <div class="large-2 columns">
                <select>
                    <option value="">男</option>
                    <option value="">女</option>
                </select>
            </div>
            <div class="large-2 columns">
                <select>
                    <option value="">省份</option>
                </select>
            </div>
            <div class="large-2 columns">
                <select>
                    <option value="">城市</option>
                </select>
            </div>
            <div class="large-2 columns">
                <select>
                    <option value="">隐藏状态</option>
                    <option value="">公开</option>
                    <option value="">隐藏</option>
                </select>
            </div>
            <div class="large-2 columns">
                <select>
                    <option value="">审核状态</option>
                    <option value="">待审核</option>
                    <option value="">审核通过</option>
                    <option value="">审核驳回</option>
                </select>
            </div>
            <div class="large-2 columns">
                <select>
                    <option value="">简历状态</option>
                    <option value="">正常</option>
                    <option value="">已删除</option>
                </select>
            </div>
            <div class="large-2 columns">
                <input type="text" name="date_from" value="2017-04-26" placeholder="学习开始时间">
            </div>
            <div class="large-2 columns">
                <input type="text" name="date_to" value="2017-04-26" placeholder="学习结束时间">
            </div>
            <div class="large-2 columns">
                <input type="text" value="" placeholder="学习课程">
            </div>
            <div class="large-2 columns">
                <input type="text" value="" placeholder="搜求职者姓名、电话">
            </div>
            <div class="large-2 columns end">
                <a href="javascript:void(0);" id="search" class="btns small blue">搜索</a>
            </div>
        </div>
    </form>
    <div class="row">
        <div class="large-12 columns pd-0">
            <table role="grid" class="cus_table">
                <thead>
                <tr>
                    <th>姓名</th>
                    <th>电话</th>
                    <th>性别</th>
                    <th>所在地区</th>
                    <th>学习课程</th>
                    <th>学习日期</th>
                    <th>职业状态</th>
                    <th>现任职位</th>
                    <th>现任机构</th>
                    <th>期望薪资</th>
                    <th>隐藏状态</th>
                    <th>审核状态</th>
                    <th>简历状态</th>
                    <th width="90">操作</th>
                </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>名字</td>
                        <td>131111111111</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><span class="t-color grey">隐藏</span></td>
                        <td><span class="t-color green">通过</span></td>
                        <td><span class="t-color red">已删除</span></td>
                        <td>
                            <a href="javascript:void(0);" data-toggle="tooltip" title="预览" class="btns tiny detail"><i class="fa fa-file-text fa-fw"></i></a>
                            <a href="javascript:void(0);" data-toggle="tooltip" title="恢复" class="btns tiny recover"><i class="fa fa-rotate-left fa-fw"></i></a>
                        </td>
                    </tr>
                    <tr>
                        <td>名字</td>
                        <td>131111111111</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>公开</td>
                        <td><span class="t-color yellow">待审核</span></td>
                        <td>正常</td>
                        <td>
                            <a href="javascript:void(0);" data-toggle="tooltip" title="预览" class="btns tiny detail"><i class="fa fa-file-text fa-fw"></i></a>
                            <a href="javascript:void(0);" data-toggle="tooltip" title="删除" class="btns tiny del"><i class="fa fa-trash fa-fw"></i></a>
                        </td>
                    </tr>
                    <tr>
                        <td>名字</td>
                        <td>131111111111</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>公开</td>
                        <td><span class="t-color red">驳回</span></td>
                        <td>正常</td>
                        <td class="action_columns">
                            <a href="javascript:void(0);" data-toggle="tooltip" title="预览" class="btns tiny detail"><i class="fa fa-file-text fa-fw"></i></a>
                            <a href="javascript:void(0);" data-toggle="tooltip" title="删除" class="btns tiny del"><i class="fa fa-trash fa-fw"></i></a>
                        </td>
                    </tr>
                    <tr><td colspan=14 style="text-align: center">暂无数据</td></tr>
                </tbody>
            </table>
        </div>
    </div>
    <!-- 分页组件 开始 -->
  </div>
</div>

<div id="detail_modal" class="reveal-modal small" data-reveal aria-hidden="true">
    <h4 class="modal-title">xxx的简历</h4>
    <div class="modal-body">
        <div class="cus_view noBorder">
                <div class="data_title tiny">
                    <b>详细信息</b>
                </div>
                <ul class="data_list">
                    <li>
                        <p><i class="title">姓名：</i>松下童子</p>
                        <p><i class="title">性别：</i>男</p>
                    </li>
                    <li>
                        <p><i class="title">手机号：</i>13671955699</p>
                        <p><i class="title">出生日期：</i>1990-10-10</p>
                    </li>
                    <li>
                        <p><i class="title">所在地区：</i>上海-上海</p>
                        <p><i class="title">职业状态：</i>在职-月内到岗</p>
                    </li>
                    <li class="rowspan">
                        <p><i class="title medium">现任职位：</i><i class="desc">你猜</i></p>
                    </li>
                    <li class="rowspan">
                        <p><i class="title medium">现任机构：</i><i class="desc">你再猜</i></p>
                    </li>
                    <li class="rowspan">
                        <p><i class="title medium">期望薪资：</i><i class="desc">100</i></p>
                    </li>
                </ul>
                <div class="data_title tiny">
                    <b>工作经历</b>
                </div>
                <ul class="data_list">
                    <li class="rowspan">
                        <p>你猜</p>
                    </li>
                </ul>
                <div class="data_title tiny">
                    <b>学员经历</b>
                </div>
                <ul class="data_list">
                    <li class="rowspan">
                        <p><i class="title medium">学习课程：</i><i class="desc">你猜</i></p>
                        <p><i class="title medium">学习日期：</i><i class="desc">2001-10-10</i></p>
                    </li>
                </ul>
                <div class="data_title tiny">
                    <b>个人照片</b>
                </div>
                <ul class="data_list">
                    <li class="rowspan">
                        <p>
                            <a href="https://pic3-s.styd.cn/9bb6ebb7fc7bd26aa49a997ffde51d1d" data-lightbox="user-photo">
                              <img src="https://pic3-s.styd.cn/9bb6ebb7fc7bd26aa49a997ffde51d1d?imageView2/2/w/60/interlace/1" alt="">
                            </a>
                            <a href="https://pic3-s.styd.cn/a52b1c6a3927f25e0b1140f067575d38" data-lightbox="user-photo">
                              <img src="https://pic3-s.styd.cn/a52b1c6a3927f25e0b1140f067575d38?imageView2/2/w/60/interlace/1" alt="">
                            </a>
                        </p>
                    </li>
                </ul>
                <div class="data_title tiny">
                    <b>资格证书</b>
                </div>
                <ul class="data_list">
                    <li class="rowspan">
                        <p>
                            <a href="https://pic3-s.styd.cn/c75064795a1bb04c8023f623ab5c0997" data-lightbox="user-certify">
                                <img src="https://pic3-s.styd.cn/c75064795a1bb04c8023f623ab5c0997?imageView2/2/w/60/interlace/1" alt="">
                            </a>
                            <a href="https://pic3-s.styd.cn/cbea930b508efc880a9f98649f926ac7" data-lightbox="user-certify">
                                <img src="https://pic3-s.styd.cn/cbea930b508efc880a9f98649f926ac7?imageView2/2/w/60/interlace/1" alt="">
                            </a>
                        </p>
                    </li>
                </ul>
              </div>

        <div class="row">
            <div class="large-12 text-center columns">
                <a href="javascript:void(0);" class="btns medium red save">驳回</a>
                <a href="javascript:void(0);" class="btns medium blue save">通过</a>
            </div>
        </div>
    </div>
    <a class="close-reveal-modal" aria-label="Close">&#215;</a>
</div>
