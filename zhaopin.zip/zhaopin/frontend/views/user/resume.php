<?php
use frontend\components\UrlService;
use frontend\components\StaticService;

StaticService::includeAppCssStatic("/css/user/resume.css",\frontend\assets\AppAsset::className());
StaticService::includeAppJsStatic("/js/user/resume.js",\frontend\assets\AppAsset::className());
StaticService::includeAppJsStatic("/js/component/qiniu.min.js",\frontend\assets\AppAsset::className());
StaticService::includeAppJsStatic("/js/component/plupload.full.min.js",\frontend\assets\AppAsset::className());
?>

    <input type="hidden" id="job_images_id" value='<?= json_encode($resume['job_images']) ?>' >
    <input type="hidden" id="body_images_id" value='<?= json_encode($resume['body_images']) ?>' >

    <div id="wrap">
    <?php if($resume['audit_status'] == 1):?>
        <p class="resume_status approved">您的简历已通过审核</p>
    <?php elseif($resume['audit_status'] == 2):?>
        <p class="resume_status reject">您的简历已驳回，请重新编辑后保存并提交</p>
    <?php elseif($resume['audit_status'] == 0):?>
            <p class="resume_status await">您的简历已提交，正待审核</p>
    <?php endif;?>
    <h3 class="resume_title">个人信息</h3>
    <div class="resume_form mgb">
        <ul class="form_list">
            <li>
                <label class="title required">姓&emsp;名:</label>
                <div class="input_box">
                    <input type="text" class="type_1" name="user_name" placeholder="请填写" value="<?= $resume['name'] ?>">
                </div>
            </li>
            <li>
                <label class="title required">性&emsp;别:</label>
                <div class="input_box arrow_right">
                    <select class="type_1" name="user_sex">
                        <option value="1" <?php if($resume['sex']==1):?> selected <?php endif;?> >男</option>
                        <option value="2" <?php if($resume['sex']==2):?> selected <?php endif;?> >女</option>
                    </select>
                </div>
            </li>
            <li>
                <label class="title required">手 机 号:</label>
                <div class="input_box">
                    <input type="tel" class="type_1" name="user_mobile" placeholder="请填写" value="<?= $user['mobile'] ?>">
                </div>
            </li>
            <li>
                <label class="title required">出生日期:</label>
                <div class="input_box arrow_right">
                    <input type="date" class="type_1 type_date" name="user_birthday" placeholder="请选择" value="<?= $resume['birthday'] ?>">
                </div>
            </li>
            <li>
                <input type="hidden" id="city_id_id_before" value="<?= $resume['city_id'] ?>">
                <label class="title required">所在地区:</label>
                <div class="input_box">
                    <select class="type_2" name="province_id" id="province_id" >
                        <option value="0">省份</option>
                        <?php foreach ($province_mapping as $_province_id => $_province_name): ?>
                            <option value="<?= $_province_id ?>"
                                    <?php if ($_province_id == $resume['province_id']): ?> selected="selected"<?php endif; ?>><?= $_province_name ?> </option>
                        <?php endforeach; ?>
                    </select>
                    <select class="type_2" name="city_id" id="city_id" >
                        <option value="<?= $resume['city_id'] ?>"><?= $resume['city'] ?></option>
                    </select>
                </div>
            </li>
        </ul>
    </div>
    <div class="resume_form">
        <ul class="form_list">
            <li>
                <label class="title required">职业状态:</label>
                <div class="input_box arrow_right">
                    <select class="type_1" name="job_status">
                        <option value="4" <?php if($resume['job_status']==4):?> selected <?php endif;?> >离职-随时到岗</option>
                        <option value="1" <?php if($resume['job_status']==1):?> selected <?php endif;?> >在职-月内到岗</option>
                        <option value="2" <?php if($resume['job_status']==2):?> selected <?php endif;?> >在职-暂不考虑</option>
                        <option value="3" <?php if($resume['job_status']==3):?> selected <?php endif;?> >在职-考虑机会</option>
                        <option value="5" <?php if($resume['job_status']==5):?> selected <?php endif;?> >实习-随时到岗</option>
                        <option value="6" <?php if($resume['job_status']==6):?> selected <?php endif;?> >实习-月内到岗</option>
                        <option value="7" <?php if($resume['job_status']==7):?> selected <?php endif;?> >兼职-随时到岗</option>
                    </select>
                </div>
            </li>
            <li>
                <label class="title">现任职位:</label>
                <div class="input_box">
                    <input name="job" type="text" class="type_1" placeholder="请填写" value="<?= $resume['job'] ?>">
                </div>
            </li>
            <li>
                <label class="title">现任机构:</label>
                <div class="input_box">
                    <input name="company" type="text" class="type_1" placeholder="请填写" value="<?= $resume['company'] ?>">
                </div>
            </li>
            <li>
                <label class="title">期望薪资:</label>
                <div class="input_box arrow_right">
                    <select class="type_1" name="salary">
                        <?php foreach ($resume['salary_list'] as $key => $value): ?>
                            <option value="<?= $value['id'] ?>" <?php if($value['selected'] > 0):?> selected="selected" <?php endif;?> ><?= $value['name'] ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
            </li>
        </ul>
    </div>
    <h3 class="resume_title">工作经历（两年内）(必填)</h3>
    <div class="resume_form">
        <div class="text_exp">
            <textarea name="job_exp" placeholder="请简要描述您近两年内工作经历" ><?= $resume['job_exp'] ?></textarea>
        </div>
    </div>
    <h3 class="resume_title">学员经历</h3>
    <div class="resume_form">
        <ul class="form_list">
            <li>
                <label class="title required">学习课程:</label>
                <div class="input_box">
                    <input  type="text" class="type_1" name="course_name" placeholder="请填写" value="<?= $resume['study_content'] ?>" >
                </div>
            </li>
            <li>
                <label class="title required">学习日期:</label>
                <div class="input_box arrow_right">
                    <input type="date" class="type_1 type_date" name="course_date" placeholder="请选择" value="<?= $resume['study_time'] ?>" >
                </div>
            </li>
        </ul>
    </div>
    <h3 class="resume_title">认证资格（证书照片）（必填）</h3>
    <div class="resume_form pdt">
        <ul id="job_images" class="upload_list user_certify">
        <?php if (count($resume['job_images']) > 0): ?>
            <?php foreach ($resume['job_images'] as $key => $value): ?>
                 <li><img src='<?= "https://pic3-s.styd.cn/".$value."?imageView2/1/w/120/h/120/interlace/1" ?>' alt=""></li>
            <?php endforeach ?>
        <?php endif ?>
        </ul>
        <form method="post" action="http://upload.qiniu.com/"  enctype="multipart/form-data">
            <div class="upload_box" id="images">
                    <div id="pickfiles_container_1" class="type_upload">
                      <input type="button" id="pickfiles_1" style="width: 100%; height: 100%" />
                    </div>
            </div>
        </form>
    </div>
    <h3 class="resume_title">个人照片（免冠照&全身照）（必填）</h3>
    <div class="resume_form mgb pdt">
        <ul id="body_images" class="upload_list user_photo">
        <?php if (count($resume['body_images']) > 0): ?>
            <?php foreach ($resume['body_images'] as $key => $value): ?>
                 <li><img src='<?= "https://pic3-s.styd.cn/".$value."?imageView2/1/w/120/h/120/interlace/1" ?>' alt=""></li>
            <?php endforeach ?>
        <?php endif ?>
        </ul>
        <form method="post" action="http://upload.qiniu.com/"  enctype="multipart/form-data">
            <div class="upload_box" id="images">
                    <div id="pickfiles_container_2" class="type_upload">
                      <input type="button" id="pickfiles_2" style="width: 100%; height: 100%" />
                    </div>
            </div>
        </form>
    </div>
    <div class="resume_form">
        <ul class="form_list">
            <li>
                <label class="title">简历公开</label>
                <div class="switch_box">
                    <input name="scope" type="checkbox" class="type_switch" <?php if($resume['scope']):?> checked="checked" <?php endif;?>>
                </div>
            </li>
        </ul>
    </div>
    <a href="javascript:void(0);" class="save">保存提交</a>
</div>
