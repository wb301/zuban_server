<?php
use frontend\components\UrlService;
use frontend\components\StaticService;

StaticService::includeAppCssStatic("/css/user/login.css",\frontend\assets\AppAsset::className());
StaticService::includeAppJsStatic("/js/user/forget.js",\frontend\assets\AppAsset::className());
?>
<div id="wrap">
    <div class="title">
        <h2>找回密码</h2>
    </div>
    <div class="login_form">
        <div class="input_wrap tel">
            <input type="tel" name="mobile" class="input_w1" placeholder="请输入手机号">
        </div>
 <!--        <div class="input_wrap captcha">
            <input type="text" name="img_captcha" class="input_w1" placeholder="请输入图片校验码">
            <img src="https://pic3-s.styd.cn/o_1avbkkvti5fs13el73s7g21c5ud.jpg" class="captcha_img" alt="">
        </div> -->
        <div class="input_wrap sms">
            <input type="text" name="sms" class="input_w1" placeholder="请输入短信验证码">
            <button class="get_sms">获取验证码</button>
        </div>
        <div class="input_wrap pwd">
            <input type="password" name="pwd" class="input_w1" maxlength="9" placeholder="请设置新密码6-9位数字、字母组合">
        </div>
    </div>
    <a href="javascript:void(0);" class="login_btn">确定</a>
</div>
