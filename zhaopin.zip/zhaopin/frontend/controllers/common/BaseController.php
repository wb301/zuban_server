<?php

namespace frontend\controllers\common;
use frontend\components\UrlService;
use Yii;

class BaseController extends \yii\web\Controller{
    public $enableCsrfValidation = false;

    protected function checkLoginUrl($url,$msg="未登录,请返回用户中心")
    {
        if(Yii::$app->request->isAjax){
            return $this->redirectAjax($url,$msg);
        }else{
            return $this->redirect($url);
        }
    }

    protected function redirectAjax($url,$msg ="", $data=[],$code = 302)
    {
        $data['url'] = Yii::$app->getRequest()->getHostInfo() . $url;
        return $this->renderJSON($data,$msg,$code);
    }

    protected function renderJSON($data=[], $msg ="ok", $code = 200){
        header('Content-type: application/json');
        echo json_encode([
            "code" => $code,
            "msg"   =>  $msg,
            "data"  =>  $data,
            "req_id" =>  $this->geneReqId(),
        ]);


        return Yii::$app->end();
    }

    protected function renderJSONP($data=[], $msg ="ok", $code = 200) {

        $func = $this->get("jsonp","jsonp_func");


        echo $func."(".json_encode([
                "code" => $code,
                "msg"   =>  $msg,
                "data"  =>  $data,
                "req_id" =>  $this->geneReqId(),
            ]).")";


        return Yii::$app->end();
    }

    protected function renderNotFound() {
        $this->renderJSON([],$msg = "ObjectNotFound", -1);
    }


    protected function geneReqId() {
        return uniqid();
    }

    public function post($key, $default = "") {
        return Yii::$app->request->post($key, $default);
    }


    public function get($key, $default = "") {
        return Yii::$app->request->get($key, $default);
    }


    protected function setCookie($name,$value, $expire=0){
        $cookies = Yii::$app->response->cookies;
        $cookies->add(new \yii\web\Cookie([
            'name' => $name,
            'value' => $value,
			'expire' => $expire
        ]));
    }

    protected  function getCookie($name,$default_val=''){
        $cookies = Yii::$app->request->cookies;
        return $cookies->getValue($name, $default_val);
    }


    protected function removeCookie($name){
        $cookies = Yii::$app->response->cookies;
        $cookies->remove($name);
    }


    protected  function renderJS($msg,$url = "/"){
        return $this->renderPartial("/common/js",['msg' => $msg,'location' => $url ]);
    }

    protected function setTitle($title = "三体云动"){
        $this->getView()->title = $title;
    }
} 