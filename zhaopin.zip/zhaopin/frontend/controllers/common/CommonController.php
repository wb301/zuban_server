<?php

namespace frontend\controllers\common;
use frontend\models\City;
use Yii;

class CommonController extends BaseController{

	public function getQiniuToken()
    {
        $bucket = 'rrrme-img';
        $config = [
        	"accessKey" => '5D2fwVt6dfAVjhjYrReKJgrJJ1NS0rn-YCDN5CLE',
            "secretKey" =>  "hueRV0rMPN493CVNv7VYxjm2tPFDROaSOhmy-m2l",
        ];

        $auth = new \Qiniu\Auth($config['accessKey'], $config['secretKey']);
        $token = $auth->uploadToken($bucket);

        return ['uptoken' => $token];
    }


    public function getSalary()
    {
        return [
            ['id' => 0, 'name' => '请选择',  'selected'=> 1],
            ['id' => 1, 'name' => '2k以下',  'selected'=> 0],
            ['id' => 2, 'name' => '2k-5k',  'selected'=> 0],
            ['id' => 3, 'name' => '5k-10k',  'selected'=> 0],
            ['id' => 4, 'name' => '10k-15k',  'selected'=> 0],
            ['id' => 5, 'name' => '15k-20k',  'selected'=> 0],
            ['id' => 6, 'name' => '20-25k',  'selected'=> 0],
            ['id' => 7, 'name' => '25-30k',  'selected'=> 0],
            ['id' => 8, 'name' => '30-40k',  'selected'=> 0],
            ['id' => 9, 'name' => '40-50k',  'selected'=> 0],
            ['id' => 10, 'name' => '50k以上',  'selected'=> 0]
        ];  
    }

    public function setSalary($returnAry)
    {
        $returnAry['salary_list'] = $this->getSalary();
        foreach ($returnAry['salary_list'] as $key => $value) {
            if(intval($returnAry['salary']) == $value['id']){
                $returnAry['salary_list'][0]['selected'] = 0;
                $returnAry['salary_list'][$key]['selected'] = 1;
                break;
            }
        }
        return $returnAry;
    }

	/**
	
		获取地区

	*/
	public function getCityList()
	{
		$ret = [];
        $province_list = City::find()->where(['city_id' => 0])->orderBy("id asc")->all();
        if( $province_list ){
            foreach( $province_list as $_province_info ){
                $ret[ $_province_info['id'] ] = $_province_info['province'];
            }
        }
        return $ret;
	}

	public function getProvinceCityTree($province_id){
        $zhixiashi_city_id = [110000,120000,310000,500000];

        $city_list = City::find()
            ->where(['province_id' => $province_id ])
            ->orderBy(['id' => SORT_ASC])
            ->all();

        $city_tree = [
            "city" => [],
            "district" => []
        ];
        if ($city_list) {
            foreach ($city_list as $_city_item) {
                if( in_array( $province_id,$zhixiashi_city_id ) ){
                    if( $_city_item['city_id'] == 0  ){
                        $city_tree['city'][] = [
                            'id' => $_city_item['id'],
                            'name' => $_city_item['name']
                        ];
                    }else{
                        $city_tree['district'][$province_id][] = [
                            'id' => $_city_item['id'],
                            'name' => $_city_item['name']
                        ];
                    }
                }else{
                    if( $_city_item['city_id'] == 0  ){
                        continue;
                    }

                    if( $_city_item['area_id'] == 0 ){
                        $city_tree['city'][] = [
                            'id' => $_city_item['id'],
                            'name' => $_city_item['name']
                        ];
                    }else{
                        $tmp_prefix_key = $_city_item['city_id'];
                        if( !isset( $city_tree['district'][$tmp_prefix_key] ) ){
                            $city_tree['district'][$tmp_prefix_key] = [];
                        }

                        $city_tree['district'][$tmp_prefix_key ][] = [
                            'id' => $_city_item['id'],
                            'name' => $_city_item['name']
                        ];
                    }
                }

            }
        }
        return $city_tree;
    }

	//批量操作检测post体
	public function getPostValue($mapping=[],$isEdit=0)
	{
		$returnAry = [];
		if(empty($mapping)){
			return $returnAry;
		}

		$postAry = Yii::$app->request->post();

		foreach ($mapping as $key => $value) {
			$type = $value[0];
			$str = isset($value[1])?$value[1]:'';
			$forced = isset($value[2])?1:0; //强行

			//如果不存在且检测
			if(!isset($postAry[$key]) && strlen($str)){
				return $this->renderJSON([],$str."不能为空",-1);
			}

			if(isset($postAry[$key])){
				$postValue = $postAry[$key];

				if($type == 'Int'){
					$postValue = $postValue?intval($postValue):0;
				}elseif($type == 'String'){
					$postValue = $postValue?trim($postValue):'';
				}

				if($forced){
					$returnAry[$key] = $postValue;
				}else{
					if($postValue){
						$returnAry[$key] = $postValue;
					}else{
						if(!$isEdit){
							return $this->renderJSON([],$str."参数错误",-1);
						}
					}
				}
			}
		}

		return $returnAry;
	}

	public function formatModel($model,$data)
	{
		foreach ($data as $key => $value) {
			$model->$key = $value;
		}
		return $model;
	}
}