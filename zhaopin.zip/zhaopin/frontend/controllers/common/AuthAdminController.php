<?php

namespace frontend\controllers\common;

use Yii;
use yii\base\InvalidParamException;
use yii\web\BadRequestHttpException;
use yii\web\Controller;
use yii\base\Action;
use frontend\models\AdminUser;
use frontend\components\UrlService;


class AuthAdminController extends CommonController {
    public $admin_user ;

    protected  $salt = "k5w#hv&0ey1smbtx";
    protected  $auth_cookie_name = "styd_zhaopin_admin";


    public $allowAllAction = [
        'admin/login',  //登录
        'admin/register', //申请试用
    ];

    public function __construct($id, $module, $config = []){
        parent::__construct($id, $module, $config = []);
    }

    public function beforeAction($action) {
        if (!in_array($action->getUniqueId(), $this->allowAllAction )) {
            if(!$this->checkLoginStatus()){
                return $this->checkLoginUrl(UrlService::buildZpUrl("/admin/login"));
            }
        }
        return true;
    }

    protected function checkLoginStatus(){
        $request = Yii::$app->request;
        $cookies = $request->cookies;
        $auth_cookie = $cookies->get($this->auth_cookie_name);

        if(!$auth_cookie){
            return false;
        }
        list($authToken,$staff_id) = explode("#",$auth_cookie);
        if(!$authToken || !$staff_id){
            return false;
        }
        
        if($staff_id && preg_match("/^\d+$/",$staff_id)){
            $userinfo = AdminUser::findOne(['id' => $staff_id,'status' => 1,'login_status' => 1]);
            if(!$userinfo){
                $this->removeAuthToken();
                return false;
            }
            if($authToken != $this->createAuthToken($userinfo['uid'],$userinfo['id'],$userinfo['login_status'],$userinfo['login_name'],$userinfo['login_pwd'],$userinfo['salt'])){
                $this->removeAuthToken();
                return false;
            }
            $this->admin_user = $userinfo;
            $view = Yii::$app->view;
            $view->params['admin_user'] = $userinfo;
            return true;
        }
        return true;
    }

    protected  function createLoginStatus($userinfo){
        $auth_token = $this->gen_log_hash( $userinfo );
        $this->setCookie($this->auth_cookie_name,$auth_token."#".$userinfo['id'],strtotime('+30day') );
    }

    protected function gen_log_hash($userinfo){
        return $this->createAuthToken($userinfo['uid'],$userinfo['id'],$userinfo['login_status'],$userinfo['login_name'],$userinfo['login_pwd'],$userinfo['salt']);
    }

    protected function createAuthToken($uid,$staff_id,$login_status,$login_name,$login_pwd,$salt){
        return md5($this->salt."-{$uid}-{$staff_id}-{$login_status}-{$login_name}-{$login_pwd}-{$salt}");
    }

    protected  function removeAuthToken(){
        $this->removeCookie($this->auth_cookie_name);
    }

    public function getBrandUid(){
        return $this->admin_user?$this->admin_user['uid']:0;
    }

    public function goHome(){
        return $this->checkLoginUrl(UrlService::buildZpUrl("/admin/login"),"");
    }
}
