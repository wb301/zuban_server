<?php

namespace frontend\controllers;
use frontend\controllers\common\AuthUserController;
use frontend\models\ZpUser AS User;
use frontend\models\SmsCaptcha;
use frontend\models\Resume;
use frontend\models\ResumeSchedule;
use frontend\components\UrlService;
use Yii;


class UserController extends AuthUserController{
    public $defaultAction = "index";

    public $layout = 'user';


    /******************************  用户 ************************************/

    public function actionIndex(){
        if($this->current_user){
            exit(json_encode($this->current_user->toArray()));
        }
        return $this->render('login');
    }


    //登录注册用
    private function renderForOk($userInfo)
    {
        $this->createLoginStatus($userInfo);
        
        return $this->redirectAjax(UrlService::buildZpUrl('/user/resume'));
    }

    /**

        登录

    */
    public function actionLogin(){
        $request = Yii::$app->request;
        if($request->isGet){
            $this->setTitle("用户登录");
            return $this->render('login');
        }

        $login_name = trim($this->post("login_name"));
        $password = trim($this->post("password"));
        if(empty($login_name) ){
            return $this->renderJSON([],"请输入正确手机号",-1);
        }

        $userinfo = User::findOne(['login_name' => $login_name]);

        if(!$userinfo){
            return $this->renderJSON([],"请输入正确的登录用户名和密码",-1);
        }
        if(!$userinfo->verifyPassword($password)){
            return $this->renderJSON([],"请输入正确的登录用户名和密码",-1);
        }

        if( !$userinfo['status'] || !$userinfo['login_status'] ){
            return $this->renderJSON([],"账号状态不对，请联系场馆",-1);
        }

        return $this->renderForOk($userinfo);
    }

    /**

        登出

    */
    public function actionLoginout(){
        $this->removeAuthToken();
        return $this->goHome();
    }

    /**

        短信

    */
    public function actionSms() {
        $mobile = Yii::$app->request->post('mobile');

        if (!$mobile || !preg_match('/^1[0-9]{10}$/', $mobile)) {
            return $this->renderJSON([],"请输入正确手机号",-1);
        }

        $last = SmsCaptcha::getLastCaptcha($mobile);

        if($last && ( time() - strtotime($last->created_time) < 60 ) ) {
            return $this->renderJSON([],"发送得太快啦",-1);
        }

        $model = new SmsCaptcha();

        if ( $model->geneCaptcha($mobile) ) {
            $rs= $model->send($mobile, "您正在App上进行操作，验证码为：".$model->captcha);

            return $this->renderJSON($rs,"发送成功");
        } else {
            return $this->renderJSON([],"发送失败",-1);
        }
    }

    /**

        注册

     */
    public function actionRegister()
    {
        if(Yii::$app->request->isGet) {
            $this->setTitle("用户注册");
            return $this->render('register');
        }

        $model = new User();

        $mobile =   trim($this->post('mobile'));
        $password = $this->post('password');
        $captcha =  $this->post("captcha");

        if(!preg_match('/^1\d{10}$/',$mobile))
        {
            return $this->renderJSON([],"请输入正确的手机号",-1);
        }

        if(User::findOne(["mobile" => $mobile])) {
            return $this->renderJSON([],"用户已存在",-1);
        }

        if ( !SmsCaptcha::checkCaptcha($mobile, $captcha) ) {
            return $this->renderJSON("","请输入正确验证码",-1);
        }

        $nickname = "用户".substr($mobile,-5);
        $_rand = '';
        while (User::findOne(['nickname'=>$nickname.$_rand])) {
            $_rand = substr(hexdec(substr(uniqid(),-6)),-4);//uniqid代替rand
        }
        $nickname = $nickname.$_rand;

        if($mobile && $password) {
            $model->setSalt();

            $model->login_name = $mobile;
            $model->mobile = $mobile;
            $model->setPassword($password);
            $model->last_active_time = date("Y-m-d H:i:s",time());
            $model->updated_time = date("Y-m-d H:i:s",time());
            $model->created_time = date("Y-m-d H:i:s",time());
            $model->nickname = $nickname;
            $model->status = 1;
            $model->login_status = 1;

            if($model->save(0)){
                $model->uid = $model->id;
                $model->save(0);

                return $this->renderForOk(User::findOne(['id' => $model->id]), 1);
            }else{
                return $this->renderJSON([],"注册失败", -1);
            }
        } else {
            return $this->renderJSON([],"参数错误", -1);
        }
    }

    /**

        重置密码

    */
    public function actionForget() {
        if(Yii::$app->request->isGet) {
            $this->setTitle("重置密码");
            return $this->render('forget');
        }

        $mobile = Yii::$app->request->post('mobile');
        $password = Yii::$app->request->post('password');
        $captcha = Yii::$app->request->post("captcha");

        if(!$mobile)
        {
            return $this->renderJSON([],"手机号不能为空",-1);
        }
        $user = User::findOne(["mobile" => $mobile]);

        if(!$user) {
            return $this->renderJSON([],"用户不存在",-1);
        }

        if ( !SmsCaptcha::checkCaptcha($mobile, $captcha) ) {
            return $this->renderJSON([],"请输入正确验证码",-1);
        }


        $user->setPassword($password);
        $user->updated_time = date("Y-m-d H:i:s",time());
        $user->save(0);

        return $this->redirectAjax(UrlService::buildZpUrl('/user/login'));
    }



    /******************************  简历 ************************************/

    public function actionCascade(){
        $province_id = $this->get('id',0);
        $tree_info = $this->getProvinceCityTree($province_id);
        return $this->renderJSON($tree_info);
    }

    public function actionQiniu_token()
    {
        echo json_encode($this->getQiniuToken());
    }

    private function initResum()
    {
        return [
            'name' => '',
            'sex' => 1,
            'mobile' => $this->current_user['mobile'],
            'birthday' => '',
            'province_id' => 0,
            'city_id' => 0,
            'study_time' => '',
            'study_content' => '',
            'scope' => '',
            'audit_status' => -2,
            'job_status' => 1,
            'status' => -1,
            'province' => '省份',
            'city' => '城市',
            'company' => '',
            'job' => '',
            'job_exp' => '',
            'salary' => '',
            'job_images' => [],
            'body_images' => [],
            'salary_list' => $this->getSalary(),
        ];
    }

    /**

        保存简历

    */
    public function actionResume() {
        $uid = $this->current_user['uid'];
        $resume_model = Resume::findOne(['uid' => $uid]);

        $returnAry = [];
        $schedule_model = new ResumeSchedule();
        if($resume_model){
            $resume_id = $resume_model->id;
            $schedule_model = ResumeSchedule::findOne(["resume_id" => $resume_id]);

            $returnAry = array_merge($resume_model->toArray(),$schedule_model->toArray());

            $returnAry['job_images'] = json_decode($returnAry['job_images'], true);
            $returnAry['body_images'] = json_decode($returnAry['body_images'], true);
            $returnAry = $this->setSalary($returnAry);
        }else{
            $resume_model = new Resume();
        }

        if(Yii::$app->request->isGet) {
            $pageTitle = "创建简历";
            $resume = $this->initResum();
            if($returnAry){
                $resume = $returnAry;
                $pageTitle = "编辑简历";
            }

            $this->setTitle($pageTitle);
            return $this->render('resume',[
                'user' => $this->current_user, 
                'resume' => $resume, 
                'province_mapping' => $this->getCityList()
            ]);
        }

        $resume_mapping = [
            'name' => ['String','姓名'],
            'sex' => ['Int','性别'],
            'mobile' => ['String','手机号'],
            'birthday' => ['String','生日'],
            'province_id' => ['Int','省'],
            'city_id' => ['Int','市'],
            'study_time' => ['String','学习时间'],
            'study_content' => ['String','学习内容'],
            'scope' => ['Int','',1],
            'job_status' => ['Int','职业状态'],
            'province' => ['String',''],
            'city' => ['String',''],
        ];
        $schedule_mapping = [
            'company' => ['String','',1],
            'job' => ['String','',1],
            'job_exp' => ['String','',1],
            'salary' => ['Int','',1],
            'job_images' => ['String','资格认证'],
            'body_images' => ['String','全身照'],
            'remark' => ['String','',1],
        ];

        $resume_data = $this->getPostValue($resume_mapping);
        if(!preg_match('/^1\d{10}$/',$resume_data['mobile']))
        {
            return $this->renderJSON([],"请输入正确的手机号",-1);
        }
        $schedule_data = $this->getPostValue($schedule_mapping);
        $nowTime = date("Y-m-d H:i:s",time());

        $resume_model->uid = $uid;
        if(!$returnAry){
            $resume_model->title = "简历";
            $resume_model->audit_status = 0;
            $resume_model->status = 1;
            $resume_model->created_time = $nowTime;
        }

        $resume_model->updated_time = $nowTime;
        $resume_model = $this->formatModel($resume_model,$resume_data);
        
        if($resume_model->save(0)){
            $schedule_model = $this->formatModel($schedule_model,$schedule_data);
            if(!$returnAry){
                $schedule_model->resume_id = $resume_model->id;
                $schedule_model->created_time = $nowTime;
            }
            $schedule_model->updated_time = $nowTime;
            $schedule_model->save(0);
        }else{
            return $this->renderJSON([],"保存失败",-1);
        }

         if(!$returnAry){
            return $this->redirectAjax(UrlService::buildZpUrl('/user/resume'),"创建成功");
        }

        return $this->redirectAjax(UrlService::buildZpUrl('/user/resume'),"保存成功");
    }
}
