<?php

namespace frontend\controllers;
use frontend\controllers\common\AuthAdminController;
use frontend\components\UrlService;
use frontend\models\AdminUser;
use frontend\models\ZpUser AS User;
use frontend\models\SmsCaptcha;
use frontend\models\Resume;
use frontend\models\ResumeSchedule;
use frontend\components\UrlService;
use Yii;


class AdminController extends AuthAdminController{
	public $defaultAction = "index";

    public $layout = 'admin';



    /******************************  用户 ************************************/

    public function actionIndex(){
        $this->layout = "blank";
        if($this->admin_user){
            exit(json_encode($this->admin_user->toArray()));
        }
        return $this->render('login');
    }

    /**

        登录

    */
    public function actionLogin(){
        $request = Yii::$app->request;
        if($request->isGet){
            $this->setTitle("用户登录");
            return $this->render('login');
        }

        $login_name = trim($this->post("login_name"));
        $password = trim($this->post("password"));
        if(empty($login_name) ){
            return $this->renderJSON([],"请输入正确手机号",-1);
        }

        $userinfo = AdminUser::findOne(['login_name' => $login_name]);

        if(!$userinfo){
            return $this->renderJSON([],"请输入正确的登录用户名和密码",-1);
        }
        if(!$userinfo->verifyPassword($password)){
            return $this->renderJSON([],"请输入正确的登录用户名和密码",-1);
        }

        if( !$userinfo['status'] || !$userinfo['login_status'] ){
        	if($userinfo['status'] == -1){
        		return $this->renderJSON([],"申请试用审核中，请耐心等待",-1);
        	}
            return $this->renderJSON([],"账号状态不对，请联系场馆",-1);
        }

        $this->createLoginStatus($userInfo);
        return $this->redirectAjax(UrlService::buildZpUrl('/admin/list'));;
    }

    /**

        登出

    */
    public function actionLoginout(){
        $this->removeAuthToken();
        return $this->goHome();
    }

    /**

        申请试用

     */
    public function actionRegister()
    {
        if(Yii::$app->request->isGet) {
            $this->setTitle("申请试用");
            return $this->render('register');
        }

        $model = new AdminUser();

        $mobile =   trim($this->post('mobile'));
        $password = $this->post('password');

        if(!preg_match('/^1\d{10}$/',$mobile))
        {
            return $this->renderJSON([],"请输入正确的手机号",-1);
        }

        if(AdminUser::findOne(["mobile" => $mobile])) {
            return $this->renderJSON([],"用户已存在",-1);
        }

        $nickname = "用户".substr($mobile,-5);
        $_rand = '';
        while (AdminUser::findOne(['nickname'=>$nickname.$_rand])) {
            $_rand = substr(hexdec(substr(uniqid(),-6)),-4);//uniqid代替rand
        }
        $nickname = $nickname.$_rand;

        if($mobile && $password) {
            $model->setSalt();

            $model->login_name = $mobile;
            $model->mobile = $mobile;
            $model->setPassword($password);
            $model->last_active_time = date("Y-m-d H:i:s",time());
            $model->updated_time = date("Y-m-d H:i:s",time());
            $model->created_time = date("Y-m-d H:i:s",time());
            $model->nickname = $nickname;
            $model->status = -1;
            $model->login_status = 1;

            if($model->save(0)){
                $model->uid = $model->id;
                $model->save(0);

                return $this->renderJSON([],"申请成功");
            }else{
                return $this->renderJSON([],"注册失败", -1);
            }
        } else {
            return $this->renderJSON([],"参数错误", -1);
        }
    }


    /**

        联盟用户列表

    */
    public function actionList(){
        $page = intval($this->get('page',1));
        $size = intval($this->get('size',20));
        $status = intval($this->get('status',-1));

        $query = AdminUser::find()->where(['status' => $status]);

        $count = intval($query->count());
        $list = [];
        if($count){
        	$list = $query->orderBy('id desc')->offset(($page-1)*$size)->limit($size)->all();
        }

        $this->setTitle("联盟列表");
        return $this->render("list",[
            'list' => $list,
            'count' => $count
        ]);
    }



    /**

        联盟用户批准

    */
    public function actionEdit(){
    	$id = intval(Yii::$app->request->post('id'));
    	$status = intval(Yii::$app->request->post('status'));

        if(!$id)
        {
            return $this->renderJSON([],"用户标识不能为空",-1);
        }
        $user = AdminUser::findOne(["id" => $id]);

        if(!$user) {
            return $this->renderJSON([],"用户不存在",-1);
        }

        if($status >= -1){
        	$user->status = $status;
        }
        $user->updated_time = date("Y-m-d H:i:s",time());

        if($user->save(0)){
        	return $this->renderJSON([],"编辑成功");
        }
        return $this->renderJSON([],"编辑失败");
    }


    /**

        简历列表

    */
    public function actionResume_list(){
    	$page = intval($this->get('page',1));
        $size = intval($this->get('size',50));

        $query = Resume::find();

        //code 条件

        $count = intval($query->count());
        $list = [];
        if($count){
        	$list = $query->orderBy('id desc')->offset(($page-1)*$size)->limit($size)->all();
        }

        $this->setTitle("简历列表");
        return $this->render("resume_list",[
            'list' => $list,
            'count' => $count
        ]);
    }

    /**

        简历预览

    */
    public function actionResume(){
        return $this->render('resume');
    	$id = intval(Yii::$app->request->get('id'));

        $resume_model = Resume::findOne(['id' => $id]);

        $returnAry = [];
        if($resume_model){
            $resume_id = $resume_model->id;
            $schedule_model = ResumeSchedule::findOne(["resume_id" => $resume_id]);

            $returnAry = array_merge($resume_model->toArray(),$schedule_model->toArray());

            return $this->render("resume",[
	            'resume' => $returnAry
	        ]);
        }
    }

    /**

        简历审核

    */
    public function actionResume_edit(){
    	$id = intval(Yii::$app->request->post('id'));
    	$audit_status = intval(Yii::$app->request->post('audit_status'));
    	$status = intval(Yii::$app->request->post('status'));

        if(!$id)
        {
            return $this->renderJSON([],"简历标识不能为空",-1);
        }
        $resume = Resume::findOne(["id" => $id]);

        if(!$resume) {
            return $this->renderJSON([],"简历不存在",-1);
        }

        if($audit_status >= 0){
        	$resume->audit_status = $audit_status;
        }
        if($status >= 0){
        	$resume->status = $status;
        }

        $resume->updated_time = date("Y-m-d H:i:s",time());

        if($resume->save(0)){
        	return $this->renderJSON([],"编辑成功");
        }
        return $this->renderJSON([],"编辑失败");
    }

}
