;
var admin_login_ops = {
    init:function(){
        this.eventBind();
        this.inputFocus();
    },
    inputFocus:function(){
      var inputBox = $("#login input");
      setTimeout(function() {
        if(inputBox.val().length > 0){
          inputBox.prev().addClass('on')
        }else{
          inputBox.prev().removeClass('on')
        }
      }, 100);
      inputBox.focus(function() {
        $(this).prev().addClass('on')
      });
      inputBox.blur(function() {
        if($(this).val() == ''){
          $(this).prev().removeClass('on')
        }
      });
    },
    eventBind:function(){
        $("#login .dologin").click(function(){
            if($("#login input[name=login_name]").val().length <= 0 ||
                $("#login input[name=login_pwd]").val().length <= 0
                ){
                alert("请输入账号和密码！");
                return false;
            }
            $("#login").submit();
        });
        document.onkeydown = function(e){
            var ev = document.all ? window.event : e;
            if(ev.keyCode==13) {
                $("#login .dologin").click();
            }
        };
    }
};
$(document).ready(function(){
    admin_login_ops.init();
});
