;
var resume_ops = {
    init:function(){
        this.selectDate();
        this.eventBind();
    },
    eventBind:function(){
        var that = this;

        $('#search_condition #search').click(function(){
            $("#search_condition").submit();
        });


        $("table .del").each(function(){
            $(this).click(function(){
                if( !confirm("确认删除？") ){
                    return;
                }
                $.ajax({
                    // code
                })
            });
        });

        $("table .detail").each(function(index, el) {
            $(this).click(function() {
                $.ajax({
                    // code
                })
                $('#detail_modal').foundation('reveal', 'open');
            });
        });
    },

    selectDate:function(){
        var options = {
            format: 'YYYY-MM-DD',
            singleDatePicker: true,
            showDropdowns: false,
            minDate:'2013-01-01',
            maxDate:'2025-01-01',
            "locale": {
                "monthNames": [
                    "1月",
                    "2月",
                    "3月",
                    "4月",
                    "5月",
                    "6月",
                    "7月",
                    "8月",
                    "9月",
                    "10月",
                    "11月",
                    "12月"
                ]
            },
            autoApply: true
        };
        $('#search_condition input[name="date_from"]').daterangepicker(options);
        $('#search_condition input[name="date_to"]').daterangepicker(options);
    },
};

$(document).ready(function(){
    resume_ops.init();
});
