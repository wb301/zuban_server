;
var common_ops = {

    eventBind:function(){


    },
    topNav:function(){
      // Topright Nav popup
      var Accordion = function(el, multiple) {
    		this.el = el || {};
    		this.multiple = multiple || false;
    		var links = this.el.find('.sys_pop');
    		links.on('click', {el: this.el, multiple: this.multiple}, this.dropdown)
      }
    	Accordion.prototype.dropdown = function(e) {
    		var $el = e.data.el;
    			$this = $(this),
    			$next = $this.next();
    		$next.toggle();
    		$this.parent().toggleClass('on_hover');
    		if (!e.data.multiple) {
    			$el.find('.mod_popup').not($next).hide().parent().removeClass('on_hover');
    		};
        var ev = e || window.event;
        if(ev.stopPropagation){
            ev.stopPropagation();
        }else if(window.event){
          window.event.cancelBubble = true;
        }
      }
    	var accordion = new Accordion($('.topNav'), false);

      $(document).click(function() {
        if($('.mail_area, .user_area').hasClass('on_hover')){
            $('.mail_area, .user_area').removeClass('on_hover');
            $('.mod_popup').hide();
        }
      });
    },
    resizeContent:function(){
      var windowHeight = $(window).height(),
          $mainContent = $(".mainContent"),
          $navLeft = $(".navInner");
      var arrHeight = [],
          mainSumHeight = 0;
      $(".topNav, .footNav, .breadCrumb, .pageBrief, .pageTab").each(function(index){
        arrHeight.push($(this).outerHeight(true));
      })
      for(var i=0;i<arrHeight.length;i++){
       mainSumHeight += arrHeight[i];
      }
      var calcNavHeight = windowHeight - $(".sys_avatar").outerHeight(true) - $(".sys_logo").outerHeight(true),
          calcMainHeight = windowHeight - mainSumHeight;
      if($mainContent.height() < calcMainHeight){
        $mainContent.css('min-height', calcMainHeight);
      }
      if($navLeft.height() < calcNavHeight){
        $navLeft.css('min-height', calcNavHeight);
      }
      // 解决页面加载时 页脚闪动问题
      $(".footNav").show();
    },
    tableActionBtns:function(){
      if($("[data-toggle='tooltip']") && $("[data-toggle='tooltip']").length){
        $('[data-toggle="tooltip"]').tooltip({
          trigger : 'hover'
        });
      }
    },
};
$(document).ready(function(){
    if($(".template").length >= 1) {
        $(document).foundation();
    }
    common_ops.resizeContent();
    common_ops.eventBind();
    common_ops.topNav();
    common_ops.tableActionBtns();

    $(window).resize(function(){
      common_ops.resizeContent();
    });
});

// 对Date的扩展，将 Date 转化为指定格式的String
// 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
// 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
// 例子：
// (new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
// (new Date()).Format("yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18
Date.prototype.Format = function(fmt)
{ //author: meizz
    var o = {
        "M+" : this.getMonth()+1,                 //月份
        "d+" : this.getDate(),                    //日
        "h+" : this.getHours(),                   //小时
        "m+" : this.getMinutes(),                 //分
        "s+" : this.getSeconds(),                 //秒
        "q+" : Math.floor((this.getMonth()+3)/3), //季度
        "S"  : this.getMilliseconds()             //毫秒
    };
    if(/(y+)/.test(fmt))
        fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));
    for(var k in o)
        if(new RegExp("("+ k +")").test(fmt))
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));
    return fmt;
};
