;
var resume_ops = {
    init:function(){
        this.eventBind();
        this.uploader();
        this.province_infos = {};
        this.images = [];

        if($("#images_id").val()){
            this.images = JSON.parse($("#images_id").val());
        }
    },
    province_cascade:function(){
        var id = $("#province_id").val();
        var province_info = this.province_infos[id];
        var city_info = province_info.city;
        if(id<=0){
            return;
        }


        $("#city_id").html("");
        $("#city_id").append("<option value='0'>请选择</option>");
        for(var idx in city_info){
            if( parseInt($("#city_id_id_before").val()) == city_info[idx]['id']){
                $("#city_id").append("<option value='"+city_info[idx]['id']+"' selected='select'>"+city_info[idx]['name']+"</option>");
                continue;
            }
            $("#city_id").append("<option value='"+city_info[idx]['id']+"'>"+city_info[idx]['name']+"</option>");
        }
    },
    eventBind:function(){
        var that = this;
        $(".tag_list li").each(function(index, el) {
            $(this).click(function() {
                $(this).toggleClass('selected');
            });
        });

        $("#province_id").change(function(){
            var id = $(this).val();
            if(id <= 0){
                return;
            }

            for(var key in that.province_infos){
                if(key == id){
                    that.province_cascade();
                    return;
                }
            }
            $.ajax({
                url :'cascade',
                data:{'id':id},
                dataType: 'json',
                success:function(res){
                    if(res.code == 200){
                        that.province_infos[id] = res.data;
                        that.province_cascade();
                    }
                }
            })
        });

        $(".save").click(function(){
            var company_name = $(".input_box input[name=company_name]").val(),
                company_mobile = $(".input_box input[name=company_mobile]").val(),
                company_info = $(".text_exp textarea[name=company_info]").val(),
                job_position = $(".input_box input[name=job_position]").val(),
                job_salary = $(".input_box select[name=job_salary]").val(),
                job_province = $(".input_box select[name=province_id]").val(),
                job_city = $(".input_box select[name=city_id]").val(),
                province = $(".input_box select[name=province_id]").find("option:selected").text(),
                city = $(".input_box select[name=city_id]").find("option:selected").text(),
                job_address = $(".input_box input[name=job_address]").val(),
                job_count = $(".input_box input[name=job_count]").val(),
                job_benefits = [],
                job_info = $(".text_exp textarea[name=job_info]").val();
            var _this = this;
            // 福利待遇
            $(".tag_list li.selected").each(function (index, item) {
                job_benefits.push($(item).val());
            });
            if( $(_this).hasClass("disabled")){
                alert("正在提交，不要重复点击！");
                return false;
            }

            if ( company_name.length <= 0 ){
                alert("请填写公司名称！");
                return false;
            }

            if( company_mobile.length <= 0 ){
                alert("请填写公司电话！");
                return false;
            }

            if ( company_info <= 0 ){
                alert("请填写公司简介！");
                return false;
            }

            if( !that.images || that.images.length <= 0){
                alert("请上传公司图片");
                return false;
            }

            if( that.images.length > 6){
                alert("最多上传六张公司图片");
                return false;
            }

            if( job_position.length <= 0 ){
                alert("请填写招聘职位！");
                return false;
            }

            if( job_salary <= 0 ){
                alert("请选择招聘薪酬！");
                return false;
            }

            if( job_province <= 0){
                alert("请选择省份!");
                return false;
            }

            if( job_city <= 0){
                alert("请选择城市!");
                return false;
            }

            if( job_address.length <= 0 ){
                alert("请填写具体地址！");
                return false;
            }

            if( job_count.length <= 0 || !/^[0-9]*$/.test(job_count) ){
                alert("请填写招聘人数，只能输入数字!");
                return false;
            }

            if ( job_info <= 0 ){
                alert("请填写岗位要求！");
                return false;
            }

            $(_this).addClass("disabled");

            job_benefits = JSON.stringify(job_benefits);
            var images = JSON.stringify(that.images);

            $.ajax({
                type: 'POST',
                url: 'edit',
                data: {
                    'name' : company_name,
                    'mobile' : company_mobile,
                    'info' : company_info,
                    'images' : images,
                    'job' : job_position,
                    'salary' : job_salary,
                    'num' : job_count,
                    'province_id' : job_province,
                    'city_id' : job_city,
                    'address' : job_address,
                    'welfare' : job_benefits,
                    'require' : job_info,
                    'province' : province,
                    'city' : city,
                },
                cache: false,
                success: function(response){
                    var response = JSON.parse(response);
                    if(response.code <= 0){
                        alert(response.msg);
                        $(_this).removeClass("disabled");
                    }else{
                        var data = response.data;
                        if(data.url){
                            if(response.msg && response.msg.length > 0){
                                alert(response.msg);
                            }
                            window.location = data.url;
                        }
                    }
                }
            });
        });
    },
    uploader: function () {
        var that = this;
        var uploader = Qiniu.uploader({
            multi_selection: true,
            runtimes: 'html5,flash,html4',
            browse_button: 'pickfiles',
            container: 'pickfiles_container',
            uptoken_url: 'qiniu_token',
            unique_names: true,
            domain: 'https://pic3-s.styd.cn/',
            get_new_uptoken: false,
            max_file_size: '100mb',
            max_retries: 3,
            auto_start: true,
            filters: {
                max_file_size: '10mb',
                mime_types: [{title: '', extensions: 'jpg,jpeg,png'}],
            },
            init: {
                FileUploaded: function(up, file, info) {
                    var info = JSON.parse(info);
                    if (that.images.length < 6) {
                        that.images.push(info.key);
                        var html =  "";
                        for (var i = 0; i < that.images.length; i++) {
                            html += '<li><img src="https://pic3-s.styd.cn/' + that.images[i]+ '?imageView2/1/w/60/h/60/interlace/1"></li>';
                        }
                        $("#images").html(html);
                    }
                },
            }
        });
    }
};

$(document).ready(function(){
    resume_ops.init();
});
