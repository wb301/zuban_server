;
var login_ops = {
    init:function(){
        this.eventBind();
    },
    eventBind:function(){
        var that = this;

        $(".login_btn").click(function(){
            var mobile = $(".input_wrap input[name=mobile]").val();
            var pwd = $(".input_wrap input[name=pwd]").val();
            var _this = this;

            if( $(_this).hasClass("disabled")){
                alert("正在提交，不要重复点击！");
                return false;
            }

            if( mobile.length <= 0 || !/^[1-9]\d{10}$/.test(mobile) ){
                alert("请输入符合要求的手机号码！");
                return false;
            }

            if ( pwd.length < 1 ){
                alert("请输入登录密码！");
                return false;
            }

            $(_this).addClass("disabled");

            $.ajax({
                type: 'POST',
                url: 'login',
                data: {
                    'login_name': mobile,
                    'password': pwd
                },
                cache: false,
                success: function(response){
                    var response = JSON.parse(response);
                    if(response.code <= 0){
                        alert(response.msg);
                        $(_this).removeClass("disabled");
                    }else{
                        var data = response.data;
                        if(data.url){
                            if(response.msg && response.msg.length > 0){
                                alert(response.msg);
                            }
                            window.location = data.url;
                        }
                    }
                }
            });
        });
    }
};

$(document).ready(function(){
    login_ops.init();
});
