;
var register_ops = {
    init:function(){
        this.eventBind();
        this.time_intervalid = null;
        this.time_count = 60;
        // this.remAdjust();
    },
    eventBind:function(){
        var that = this;
        $(".input_wrap .get_sms").click(function(){
            var mobile = $(".input_wrap input[name=mobile]").val();
            // var img_captcha = $(".input_wrap input[name=img_captcha]").val();

            if($(this).hasClass("disabled")){
                return false;
            }

            if( mobile.length <= 0 ||  !/^[1-9]\d{10}$/.test( mobile ) ){
                alert("请输入符合要求的手机号码！");
                return false;
            }

            // if( img_captcha.length < 1){
            //     alert("请输入图形校验码！");
            //     return false;
            // }

            that.lightenOrDisabled("disabled");

            $.ajax({
                type: 'POST',
                url: 'sms',
                data: {
                    'mobile': mobile
                },
                cache: false,
                success: function(response){
                    var response = JSON.parse(response);
                    that.lightenOrDisabled("countdown");
                    // if(response.code <= 0){
                        // alert(response.msg);
                    // }
                }
            });
        });

        $(".login_btn").click(function(){
            var mobile = $(".input_wrap input[name=mobile]").val();
            // var captcha = $(".input_wrap input[name=img_captcha]").val();
            var sms = $(".input_wrap input[name=sms]").val();
            var pwd = $(".input_wrap input[name=pwd]").val();
            var _this = this;

            if( $(_this).hasClass("disabled")){
                alert("正在提交，不要重复点击！");
                return false;
            }

            if( mobile.length <= 0 || !/^[1-9]\d{10}$/.test(mobile) ){
                alert("请输入符合要求的手机号码！");
                return false;
            }

            // if ( captcha.length < 1 ){
            //     alert("请输入验证码！");
            //     return false;
            // }

            if ( sms.length < 1 ){
                alert("请输入验证码！");
                return false;
            }

            if ( pwd.length < 1 ){
                alert("请输入密码！");
                return false;
            }

            $(_this).addClass("disabled");

            $.ajax({
                type: 'POST',
                url: 'register',
                data: {
                    'mobile': mobile,
                    'password': pwd,
                    'captcha' : sms
                },
                cache: false,
                success: function(response){
                    var response = JSON.parse(response);
                    if(response.code <= 0){
                        alert(response.msg);
                        $(_this).removeClass("disabled");
                    }else{
                        var data = response.data;
                        if(data.url){
                            if(response.msg && response.msg.length > 0){
                                alert(response.msg);
                            }
                            window.location = data.url;
                        }
                    }
                }
            });
        });
    },
    lightenOrDisabled:function( type ){
        if( type == "disabled" ){
            $(".input_wrap .get_sms").addClass("disabled");
        }else if( type == "light" ){
            $(".input_wrap .get_sms").removeClass("disabled");
        }else if( type == "countdown" ){
            $(".input_wrap .get_sms").addClass("disabled");
            this.time_intervalid = setInterval(this.setCaptchaTips, 1000);
        }
    },
    setCaptchaTips:function(){//倒计时提示
        register_ops.time_count--;
        if(register_ops.time_count <= 0 ){
            clearInterval(register_ops.time_intervalid);
            register_ops.lightenOrDisabled("light");
            register_ops.time_count = 60;
            $(".input_wrap .get_sms").html("获取验证码");
            return;
        }
        $(".input_wrap .get_sms").html(register_ops.time_count + " 重新获取");

    }
};

$(document).ready(function(){
    register_ops.init();
});
