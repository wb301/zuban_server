;
var common_ops = {
    init:function(){
        this.eventBind();
        this.remAdjust();
    },
    eventBind:function() {

    },
    remAdjust:function() {
        function fontsize_resize() {
            var window_width=$(window).width();
            if(window_width <= 320) {
                $('html').css('font-size','17px');
            }
        }
        fontsize_resize();
        $(window).resize(fontsize_resize);
    }
}

$(document).ready(function() {
    common_ops.init();
});
