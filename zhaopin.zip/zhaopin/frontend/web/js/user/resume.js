;
var resume_ops = {
    init:function(){
        this.eventBind();
        this.uploader1();
        this.uploader2();
        this.job_images = [];
        this.body_images = [];
        this.province_infos = {};

        if($("#job_images_id").val()){
            this.job_images = JSON.parse($("#job_images_id").val());
        }
        if($("#body_images_id").val()){
            this.body_images = JSON.parse($("#body_images_id").val());
        }
    },
    province_cascade:function(){
        var id = $("#province_id").val();
        var province_info = this.province_infos[id];
        var city_info = province_info.city;
        if(id<=0){
            return;
        }


        $("#city_id").html("");
        $("#city_id").append("<option value='0'>请选择</option>");
        for(var idx in city_info){
            if( parseInt($("#city_id_id_before").val()) == city_info[idx]['id']){
                $("#city_id").append("<option value='"+city_info[idx]['id']+"' selected='select'>"+city_info[idx]['name']+"</option>");
                continue;
            }
            $("#city_id").append("<option value='"+city_info[idx]['id']+"'>"+city_info[idx]['name']+"</option>");
        }
    },
    eventBind:function(){
        var that = this;

        $("#province_id").change(function(){
            var id = $(this).val();
            if(id <= 0){
                return;
            }

            for(var key in that.province_infos){
                if(key == id){
                    that.province_cascade();
                    return;
                }
            }
            $.ajax({
                url :'cascade',
                data:{'id':id},
                dataType: 'json',
                success:function(res){
                    if(res.code == 200){
                        that.province_infos[id] = res.data;
                        that.province_cascade();
                    }
                }
            })
        });


        $(".save").click(function(){
            var user_name = $(".input_box input[name=user_name]").val(),
                user_sex = $(".input_box select[name=user_sex]").val(),
                user_mobile = $(".input_box input[name=user_mobile]").val(),
                user_birthday = $(".input_box input[name=user_birthday]").val(),
                address_province = $(".input_box select[name=province_id]").val(),
                address_city = $(".input_box select[name=city_id]").val(),
                job_status = $(".input_box select[name=job_status]").val(),
                course_name = $(".input_box input[name=course_name]").val(),
                course_date = $(".input_box input[name=course_date]").val(),
                province = $(".input_box select[name=province_id]").find("option:selected").text(),
                city = $(".input_box select[name=city_id]").find("option:selected").text(),
                salary = $(".input_box select[name=salary]").val(),
                scope = $('input[name="scope"]:checked').val(),
                company = $(".input_box input[name=company]").val(),
                job = $(".input_box input[name=job]").val(),
                job_exp = $(".text_exp textarea[name=job_exp]").val();
            var _this = this;

            if( $(_this).hasClass("disabled")){
                alert("正在提交，不要重复点击！");
                return false;
            }

            if ( user_name.length <= 0 ){
                alert("请填写姓名！");
                return false;
            }

            if( user_sex <= 0){
                alert("请选择性别!");
                return false;
            }

            if( user_mobile.length <= 0 || !/^[1-9]\d{10}$/.test(user_mobile) ){
                alert("请填写符合要求的手机号码！");
                return false;
            }

            if ( user_birthday.length <= 0 ){
                alert("请填写出生日期！");
                return false;
            }

            if( address_province <= 0){
                alert("请选择省份!");
                return false;
            }

            if( address_city <= 0){
                alert("请选择城市!");
                return false;
            }

            if( job_status <= 0){
                alert("请选择职业状态!");
                return false;
            }

            if ( job_exp <= 0 ){
                alert("请填写工作经历！");
                return false;
            }

            if ( course_name.length <= 0 ){
                alert("请填写学习课程！");
                return false;
            }

            if ( course_date.length <= 0 ){
                alert("请填写学习日期！");
                return false;
            }

            if ( that.job_images.length <= 0 ) {
                alert("请上传认证资格照片！");
                return false;
            }

            if ( that.job_images.length > 6 ) {
                alert("最多上传九张认证资格照片！");
                return false;
            }

            if (  that.body_images.length <= 1) {
                alert("请上传个人照片！");
                return false;
            }
            if (  that.body_images.length > 2) {
                alert("最多上传两张个人照片！");
                return false;
            }

            $(_this).addClass("disabled");

            //格式化上传数据
            if(scope == 'on'){scope = 1;}else{scope = 0;}
            var remark = province+'-'+city;
            var job_images = JSON.stringify(that.job_images);
            var body_images = JSON.stringify(that.body_images);
            $.ajax({
                type: 'POST',
                url: 'resume',
                data: {
                    'name': user_name,
                    'sex': user_sex,
                    'mobile': user_mobile,
                    'birthday': user_birthday,
                    'province_id': address_province,
                    'city_id': address_city,
                    'province':province,
                    'city':city,
                    'study_time': course_date,
                    'study_content': course_name,
                    'scope': scope,
                    'job_status': job_status,
                    'job_images': job_images,
                    'body_images':body_images,
                    'company':company,
                    'job':job,
                    'job_exp': job_exp,
                    'salary': salary,
                    'remark': remark
                },
                cache: false,
                success: function(response){
                    var response = JSON.parse(response);
                    if(response.code <= 0){
                        alert(response.msg);
                        $(_this).removeClass("disabled");
                    }else{
                        var data = response.data;
                        if(data.url){
                            if(response.msg && response.msg.length > 0){
                                alert(response.msg);
                            }
                            window.location = data.url;
                        }
                    }
                }
            });
        });
    },
    uploader1: function () {
        var that = this;
        var uploader = Qiniu.uploader({
            multi_selection: true,
            runtimes: 'html5,flash,html4',
            browse_button: 'pickfiles_1',
            container: 'pickfiles_container_1',
            uptoken_url: 'qiniu_token',
            unique_names: true,
            domain: 'https://pic3-s.styd.cn/',
            get_new_uptoken: false,
            max_file_size: '100mb',
            max_retries: 3,
            auto_start: true,
            filters: {
                max_file_size: '10mb',
                mime_types: [{title: '', extensions: 'jpg,jpeg,png'}],
            },
            init: {
                FileUploaded: function(up, file, info) {
                    var info = JSON.parse(info);
                    if (that.job_images.length < 9) {
                        that.job_images.push(info.key);
                        var html =  "";
                        for (var i = 0; i < that.job_images.length; i++) {
                            html += '<li><img src="https://pic3-s.styd.cn/' + that.job_images[i]+ '?imageView2/1/w/60/h/60/interlace/1"></li>';
                        }
                        $("#job_images").html(html);
                    }
                },
            }
        });
    },
    uploader2: function () {
        var that = this;
        var uploader = Qiniu.uploader({
            multi_selection: true,
            runtimes: 'html5,flash,html4',
            browse_button: 'pickfiles_2',
            container: 'pickfiles_container_2',
            uptoken_url: 'qiniu_token',
            unique_names: true,
            domain: 'https://pic3-s.styd.cn/',
            get_new_uptoken: false,
            max_file_size: '100mb',
            max_retries: 3,
            auto_start: true,
            filters: {
                max_file_size: '10mb',
                mime_types: [{title: '', extensions: 'jpg,jpeg,png'}],
            },
            init: {
                FileUploaded: function(up, file, info) {
                    var info = JSON.parse(info);
                    if (that.body_images.length < 2) {
                        that.body_images.push(info.key);
                        var html =  "";
                        for (var i = 0; i < that.body_images.length; i++) {
                            html += '<li><img src="https://pic3-s.styd.cn/' + that.body_images[i]+ '?imageView2/1/w/60/h/60/interlace/1"></li>';
                        }
                        $("#body_images").html(html);
                    }
                },
            }
        });
    }
};

$(document).ready(function(){
    resume_ops.init();
});
