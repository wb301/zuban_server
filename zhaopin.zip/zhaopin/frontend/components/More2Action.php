<?php
namespace frontend\components;

use Yii;
use yii\base\Action;

class More2Action extends Action
{
    public function run()
    {
        var_dump(Yii::$app->request);
        var_dump(Yii::$app->request->get());
        var_dump(Yii::$app->request->post());
        return "run More2Action of HeController in MoreAction.php of frontend\components";
    }
}