<?php /*saas 内部静态文件同意加载*/
namespace frontend\components;

use Yii;
use yii\helpers\Url;

class UrlService
{

    public static function buildZpUrl($uri){
        return $uri;
    }


    public static function buildNullUrl(){
    	return 'javascript:void(0);';
	}
}
