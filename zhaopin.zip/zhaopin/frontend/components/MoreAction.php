<?php

namespace frontend\components;

use yii\base\Action;
use Yii;

class MoreAction extends Action
{
    function run()
    {
        var_dump(Yii::$app->request);
        var_dump(Yii::$app->request->post());
        var_dump(Yii::$app->request->get());
        echo "run more action of HeController in MoreAction.php of frontend\components";
    }
}