<?php
namespace frontend\components;

use Yii;
use yii\base\ActionFilter;


class MyActionTimeFilter extends ActionFilter
{
	private $_startTime;
	
	function beforeAction($action)
	{
		$this->_startTime = microtime(true);
		return parent::beforeAction($action);
	}
	
	function afterAction($action, $result)
	{
		$time = microtime(true) - $this->_startTime;
		Yii::trace("Action '{$action->uniqueId}' spent $time second.");
		return parent::afterAction($action, $result);
	}
}