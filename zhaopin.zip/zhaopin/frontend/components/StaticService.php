<?php
/*SASS 内部静态文件同意加载*/
namespace frontend\components;

use Yii;

class StaticService {

    public static function includeAppStatic($type, $path,$depend){
        $release_version = defined("RELEASE_VERSION")?RELEASE_VERSION:"20150731141600";
        $path = $path."?version={$release_version}";
        if($type=="css"){
            Yii::$app->getView()->registerCssFile($path,['depends'=>$depend]);
        }else{
            Yii::$app->getView()->registerJsFile($path,['depends'=>$depend]);
        }

    }

    public static function includeAppJsStatic($path,$depend){
        self::includeAppStatic("js",$path,$depend);
    }

    public static function includeAppCssStatic($path,$depend){
        self::includeAppStatic("css",$path,$depend);
    }
    public static function buildStaticUrl($path,$add_version=false){
        if($add_version){
            $release_version = defined("RELEASE_VERSION")?RELEASE_VERSION:"20150731141600";
            $path = $path."?version={$release_version}";
        }

        if( substr($path,0,1) != "/" ){
            $path = "/".$path;
        }

        return $path;
    }
} 
